import React, { useEffect, useState } from 'react'
import { Col, Row } from 'react-bootstrap'
import VideoCard from './VideoCard'
import { getAllVideos } from '../service/allApi'







function View({ setResponse }) {
  const [allvideos, setAllVideos] = useState([])
  const [deletevideoResponse,setDeletevideo]=useState("")
  
  
  useEffect(() => {
    getAllVideo()
  }, [setResponse,deletevideoResponse])
  console.log(allvideos);

  const getAllVideo = async () => {
    try {
      const result = await getAllVideos()
      // console.log(result);

      if (result.status >= 200 && result.status < 300) {
        setAllVideos(result.data)
      }

    }
    catch (err) {
      console.log(err);

    }
  }

  return (
    <>
      <Row className='border border-3'>

        {

          allvideos.length > 0 ?
            allvideos?.map(video => (
              <Col key={video?.id} lg={4} mb={6} sm={12}>

                <VideoCard displayData={video} def={setDeletevideo} />
              </Col>
            ))
             :
            <div className='text-danger fs-3 fw-bold'>Nothing to display</div>

        }


      </Row>
    </>
  )
}

export default View