import React, { useState } from 'react'

import { Link } from 'react-router-dom'
import Add from '../components/Add'
import View from '../components/View'
import Category from '../components/Category'





function Home() {
  const [addVideosResponse,setaddVideoResponse]=useState("")

  
  
  return (
    <>
    <div className='container d-flex justify-content-between '>
      <Add setaddVideoResonse={setaddVideoResponse}/>
      
      <Link className='text-warning fw-bold fs-5' style={{textDecoration:'none'}} to={'/history'}>Watch History</Link>
  
    </div>
    <div className="row container-fluid my-5">
      <div className="col-lg-6">
        <View setResponse={addVideosResponse}/>
        </div>
    <div className="col-lg-6"><Category/></div>
    </div>
    </>
  )
}

export default Home