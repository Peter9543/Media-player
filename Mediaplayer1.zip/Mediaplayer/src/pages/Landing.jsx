import React from 'react'
import landingimage from '../assets/mediaplayer.gif'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import settingimiage from '../assets/setting-image.webp'
import manageimage from'../assets/manage-image.jpg'
import historyimage from '../assets/history-image.jpg'

function Landing() {
  return (
    <>
    <div className='row'>
    <div className='col'>
        <h1>Welcome to <span className='text-danger'>Media Player</span></h1>
        <p className='d-flex justify-content-center'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat accusamus iste voluptatibus rerum deserunt voluptatem aliquid. Qui aut numquam suscipit quo, deleniti saepe illo incidunt id a facere iusto corporis.
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit, sed voluptas veritatis praesentium quia dolore facilis voluptate, nostrum magni sequi dolores placeat non eveniet numquam aliquam eligendi delectus illo perferendis?

        </p>
        <button type="button" class="btn btn-success">Success</button>
    </div>
    <div className='col'>
      <img src={landingimage} alt="" />

    </div>
   <div className='row'>
    <span className='text-warning font ' style={{fontSize:'35px'}}>Features </span>
     <div className='col'>
        <Card style={{ width: '18rem' }}>
          <Card.Img variant="top" src={settingimiage} />
          <Card.Body>
            <Card.Title>Managing videos</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
            
          </Card.Body>
        </Card>
        
        
     </div>
     <div className='col'>
        <Card style={{ width: '18rem' }}>
          <Card.Img variant="top" src={manageimage} />
          <Card.Body>
            <Card.Title>Categorize videos</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          
          </Card.Body>
        </Card>
        
        
     </div>
     <div className='col'>
        <Card style={{ width: '18rem' }}>
          <Card.Img variant="top" src={historyimage} />
          <Card.Body>
            <Card.Title>Manage History</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
            
          </Card.Body>
        </Card>
        
        
     </div>
   </div>
   <div className='ms-5 mt-5' style={{width:'1400px',height:'500px',border:'solid'}}>

    <div className="row">
      <div className="col-md-8"><h3 className='text text-warning ms-2'>simple,fast and powerful</h3>
    <div className='d-flex'>  <p className='fw-boldm ms-3'>Play Everything: <span>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Commodi vero nobis modi fugit dolorem aut, error, culpa impedit dolores non enim consequuntur dignissimos quae accusamus debitis. Sed earum placeat atque!
      </span></p></div>
      <p className='fw-boldm ms-3 mt-5'> categorize video: <span>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Earum porro eum quasi quaerat commodi enim dolorum illum, suscipit nostrum iste quod. Delectus esse vitae incidunt rem ratione at possimus nemo.
        </span> </p>
    <p className='fw-boldm ms-3 mt-5 '>Managing history:<span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate sapiente rem quidem a illo doloremque iure tempora ab alias. Itaque nostrum nisi veritatis reprehenderit sunt. Ipsum natus a corrupti assumenda.</span></p></div>
    <div className="col"><iframe width="400" height="300" src="https://www.youtube.com/embed/TmpzntdJqm4?si=1zEq2y2ZCYZR6x_g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
      </div></div>
  </div>
    </div>
    
    </>
  )
}

export default Landing