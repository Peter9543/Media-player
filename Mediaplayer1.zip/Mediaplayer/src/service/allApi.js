import CommonAPI from "./CommonApi"
import SERVER_URL from "./SERVER_URL"

//save video
//save video api called by add.jsx

export const addVideo=async(video)=>{
    return await CommonAPI("POST",`${SERVER_URL}/allvideos`,video)
 }
 
 //api call for get 
 export const getAllVideos=async()=>{
   return await CommonAPI("GET",`${SERVER_URL}/allvideos`,"")
 }

 //video delete
 export const deleteVideos=async(videoid)=>{
  return await CommonAPI("DELETE",`${SERVER_URL}/allvideos/${videoid}`,{})
}
//save history api call
export const saveHistory=async(video)=>{
  return await CommonAPI("POST",`${SERVER_URL}/History`,video)
}

//api call for get history
export const getallhistory=async(video)=>{
  return await CommonAPI("GET",`${SERVER_URL}/History`,"")
}


  